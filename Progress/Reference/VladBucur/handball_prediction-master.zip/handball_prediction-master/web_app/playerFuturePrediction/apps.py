from django.apps import AppConfig


class PlayerfuturepredictionConfig(AppConfig):
    name = 'playerFuturePrediction'
