from django.apps import AppConfig

class PlayerpredictionConfig(AppConfig):
    name = 'playerPrediction'
