from django.apps import AppConfig

class PlayerfuturepredictionresultConfig(AppConfig):
    name = 'playerFuturePredictionResult'
