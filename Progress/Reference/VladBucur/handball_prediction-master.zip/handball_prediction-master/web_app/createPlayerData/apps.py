from django.apps import AppConfig


class CreateplayerdataConfig(AppConfig):
    name = 'createPlayerData'
