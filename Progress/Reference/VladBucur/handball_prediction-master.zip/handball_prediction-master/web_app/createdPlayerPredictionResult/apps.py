from django.apps import AppConfig

class CreatedplayerpredictionresultConfig(AppConfig):
    name = 'createdPlayerPredictionResult'
