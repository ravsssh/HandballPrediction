from django.apps import AppConfig

class PlayersearchConfig(AppConfig):
    name = 'playerSearchResult'
