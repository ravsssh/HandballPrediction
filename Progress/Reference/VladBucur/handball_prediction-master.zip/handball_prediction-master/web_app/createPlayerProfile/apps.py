from django.apps import AppConfig


class CreateplayerprofileConfig(AppConfig):
    name = 'createPlayerProfile'
