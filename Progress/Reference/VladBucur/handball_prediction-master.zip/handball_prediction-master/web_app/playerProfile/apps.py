from django.apps import AppConfig

class PlayerprofileConfig(AppConfig):
    name = 'playerProfile'
