from django.apps import AppConfig

class PlayerfuturepredictioninputdataConfig(AppConfig):
    name = 'playerFuturePredictionInputData'
