from django.apps import AppConfig

class PredictionresultConfig(AppConfig):
    name = 'predictionResult'
