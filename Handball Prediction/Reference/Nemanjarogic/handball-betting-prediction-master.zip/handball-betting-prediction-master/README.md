**<h1>
Handball betting prediction
</h1>**

Aim of this project is accomplishing a quality prediction for the final scores in Germany Bundesliga handball games
as well as accomplishing high accuracy of the prediction.
For assistance in that task will be used an artificial neural network.


<h2>
Directories
</h2>

<b>1. DataSet</b>
   <br/><b>   1.1 Predict</b>
   <br/>         Files for final prediction after training of the artificial neural network. For the prediction we have one round in Bundesliga written in excel file, and ANN makes a prediction for that round. The round written in excel file will be played in future.
   <br/><b>   1.2 Test</b>
   <br/>         Test files which is used in calculation for the accuracy of the prediction.
   <br/><b>   1.3 Train</b>
   <br/>         Files for the training of the artificial neural network.




